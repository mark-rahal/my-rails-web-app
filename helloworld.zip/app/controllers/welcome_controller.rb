class WelcomeController < ApplicationController
  def index
    @name = 'Mark'
  end
end
