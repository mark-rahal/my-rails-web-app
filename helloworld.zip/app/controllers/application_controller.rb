class ApplicationController < ActionController::Base
  def hello
  end
end
